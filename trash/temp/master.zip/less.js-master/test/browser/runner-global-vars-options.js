var less = {};
less.globalVars = {
  "@global-var": "red"
};
